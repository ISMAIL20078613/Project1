# Blooger Website

Create a Blog web App Creating User Blog , Started as a school project.

## Technologies Used:

* HTML5
* CSS3
* JavaScript

## Silent Features:

* Responsive Design.
* Portfolio Template.
* Unique and Dynamic Design.
* Contains HOME, CATEGORY, ARCHIVE, PAGES, CONTACT and many other sections.




[Click Button Demo And View Project Live](https://mian-ali.github.io/Blooger-website/)





## Project Preview:

(https://mian-ali.github.io/Blooger-website/)
